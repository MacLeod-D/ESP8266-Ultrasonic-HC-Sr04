var structtask =
[
    [ "Delay", "structtask.html#ad9e3002f702a81c5757160bbf51c9777", null ],
    [ "Func", "structtask.html#a7c806c5ed36abd719279e65613d9e9d4", null ],
    [ "ID", "structtask.html#a65ebe86215464bad861b8cf4baf83da9", null ],
    [ "LastCalled", "structtask.html#a4feb00fbdeda462c98953d6bf34a48fe", null ],
    [ "Name", "structtask.html#adfbf07625061b6694a378587937a5158", null ],
    [ "Priority", "structtask.html#accd101c39c1f4c67dc8a2f9a48be3dc8", null ],
    [ "State", "structtask.html#a62722aa27531799459583309d925c1f4", null ]
];