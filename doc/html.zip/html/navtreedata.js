var NAVTREE =
[
  [ "CoopOS_Demo1_Ultrasonic_ESP8266_Arduino_IDE", "index.html", [
    [ "CoopOS_Simplest-Demo1 / ESP8266-Version / Arduino-IDE", "index.html", "index" ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_esp8266___coop_o_s___demo1___ultraschall_8ino.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';