var annotated_dup =
[
    [ "mySerial", "classmy_serial.html", "classmy_serial" ],
    [ "task", "structtask.html", "structtask" ]
];