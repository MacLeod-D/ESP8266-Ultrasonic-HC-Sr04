var searchData=
[
  ['task',['task',['../structtask.html',1,'']]],
  ['taskswitch_20_2dmacros',['TaskSwitch -Macros',['../ts.html',1,'index']]]
];
