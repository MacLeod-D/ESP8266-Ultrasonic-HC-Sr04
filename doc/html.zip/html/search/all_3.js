var searchData=
[
  ['myserial',['mySerial',['../classmy_serial.html',1,'']]]
];
